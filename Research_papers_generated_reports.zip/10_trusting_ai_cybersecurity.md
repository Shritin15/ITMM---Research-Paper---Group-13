# 10_trusting_ai_cybersecurity
Title: Trusting AI in Cybersecurity: An Empirical Study of Perceptions on Ethical Decision-Making
Link:  https://doi.org/10.48009/2_iis_2024_121

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Organizations using AI in cybersecurity should be transparent about their ethical guidelines.
- Notes: Transparency emphasized as key for ethical governance and trust.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Educating the public about AI’s capabilities and limitations could improve overall trust and reliability perceptions.
- Notes: Explainability and communication drive trust and user understanding.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Regulations and standards should ensure AI systems in cybersecurity are developed and used in an ethically responsible manner.
- Notes: Accountability associated with legal and institutional mechanisms for governance.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Human oversight is necessary to ensure the ethical use of AI in cybersecurity.
- Notes: Human supervision considered essential to maintain ethical control.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Participants expressed concern about AI invading personal privacy in cybersecurity.
- Notes: Privacy concerns central to ethical risk perception and acceptance.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Regulatory frameworks play a significant role in ensuring adherence with ethical principles, data privacy regulations, and accountability mechanisms.
- Notes: Data protection seen as a regulatory and operational requirement.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ethics cannot be static—systems must be evaluated continuously as technologies evolve.
- Notes: Promotes continuous ethical review and lifecycle monitoring.
