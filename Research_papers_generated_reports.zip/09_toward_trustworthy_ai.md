# 09_toward_trustworthy_ai
Title: Toward Trustworthy AI Development: Mechanisms for Supporting Verifiable Claims
Link:  https://www.cfi.cam.ac.uk/publications/toward-trustworthy-ai-development

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Developers should make claims about system behavior verifiable through documentation, testing, and transparency mechanisms.
- Notes: Transparency operationalized through verifiable claims and open documentation.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Explainability is key to verifying AI systems’ fairness, robustness, and reliability.
- Notes: Interpretability positioned as core to measurable trustworthiness.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Accountability requires clear allocation of responsibility for AI outcomes, including documentation of decision rationales.
- Notes: Responsibility mapped through audit trails and traceable system claims.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Human oversight should be maintained through review and audit processes integrated into the AI lifecycle.
- Notes: Oversight framed as procedural and ongoing throughout system development.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Trustworthiness depends on respecting privacy and security obligations throughout the system lifecycle.
- Notes: Privacy and security integrated as continuous assurance domains.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Mechanisms for data traceability and governance should accompany assurance processes.
- Notes: Data governance mechanisms linked with traceability and accountability.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Trustworthy AI development involves continuous monitoring, assessment, and updating of claims as systems evolve.
- Notes: Explicitly advocates adaptive oversight and lifecycle monitoring.
