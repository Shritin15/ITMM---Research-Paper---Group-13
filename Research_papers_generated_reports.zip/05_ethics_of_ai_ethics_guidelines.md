# 05_ethics_of_ai_ethics_guidelines
Title: The Ethics of AI Ethics: An Evaluation of Guidelines
Link:  https://doi.org/10.1007/s11023-020-09517-8

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Transparency is one of the most frequently mentioned principles, yet often lacks specific mechanisms for implementation.
- Notes: Highlights transparency as a recurring but weakly operationalized theme in most guidelines.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Explainability is connected to fairness and accountability; many guidelines emphasize it as key for user trust.
- Notes: Explainability identified as technically feasible but often limited to conceptual statements.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Accountability is discussed in nearly all guidelines but remains vague, often shifting responsibility to organizations rather than individuals.
- Notes: Accountability treated as an ethical ideal rather than enforceable standard.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - While human control and oversight are mentioned frequently, few frameworks describe concrete auditing or intervention mechanisms.
- Notes: Human-in-the-loop oversight cited as necessary but underdefined in practice.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Privacy is among the most consistent ethical dimensions, focusing on personal data protection and informed consent.
- Notes: Privacy principles widely included, yet undermined by weak regulatory enforcement and surveillance trends.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Data protection and security are common, with technical measures like anonymization and differential privacy mentioned.
- Notes: Data protection linked closely with technical safeguards but limited societal impact discussed.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 8 / 15  (Implicit/weak evidence → 50% weight)
- Evidence pointers:
  - Ethics is often treated as a static checklist rather than a continuous process of monitoring and adaptation.
- Notes: Identified absence of continuous ethical governance mechanisms; ethics lacks dynamic feedback structures.
