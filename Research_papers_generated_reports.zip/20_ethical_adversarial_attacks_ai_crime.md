# 20_ethical_adversarial_attacks_ai_crime
Title: The Double-Edged Sword of AI: Ethical Adversarial Attacks to Counter Artificial Intelligence for Crime
Link:  https://doi.org/10.1007/s43681-021-00113-9

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Such tools and techniques should be created along with relevant legal and ethical frameworks so all users and societies understand how and why EAA are applied.
- Notes: Transparency supports accountability and trust in EAA.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - It is crucial for such AI solutions to be explainable and fair, following the xAI (explainable AI) paradigm.
- Notes: Explicitly ties to xAI for ensuring fairness and understanding.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ethical questions of EAAs must be properly addressed to build trust among citizens, businesses, and policymakers.
- Notes: Accountability positioned as foundation for legitimacy of ethical AI countermeasures.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Cybersecurity experts should start resorting to an ethical method modelled on Adversarial Attacks to counteract the activity of criminals.
- Notes: Human supervision ensures ethical use of EAA technologies.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Cybersecurity must be concerned with ethical behaviour as a way of guaranteeing the protection of people’s freedom and privacy.
- Notes: Privacy highlighted as a moral imperative of cybersecurity ethics.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Cybersecurity protects people's assets, removes vulnerabilities, and safeguards systems.
- Notes: Emphasizes integrity and confidentiality in cyber defense ethics.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Methods of this kind should be included in national and international research strategies and roadmaps to ensure ethical issues are continuously addressed.
- Notes: Promotes ongoing ethical oversight and governance frameworks.
