# 08_ethical_governance_trust_ai
Title: Ethical Governance is Essential to Building Trust in Robotics and Artificial Intelligence Systems
Link:  https://doi.org/10.1098/rsta.2018.0085

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Transparency is a core principle of ethical governance… organizations should publish terms of reference and evidence of ethical practice.
- Notes: Transparency central to trust-building and governance credibility.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Systems should be explainable or capable of explaining their actions to non-experts.
- Notes: Explainability ensures accountability and facilitates post-incident analysis.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Responsibility for AI actions must remain with human designers and operators, not the systems themselves.
- Notes: Assigns moral and legal accountability explicitly to human stakeholders.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Humans must retain meaningful control and the capacity to override AI decisions.
- Notes: Supports strong human oversight and ethical intervention.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Societal hazards include loss of trust, deception, privacy and confidentiality.
- Notes: Privacy identified as a core dimension of societal trust and ethical risk management.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI systems must integrate data minimization and security principles to prevent misuse.
- Notes: Data protection linked to responsible design and regulatory compliance.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ethics cannot be static… systems must be evaluated continuously as technologies evolve.
- Notes: Encourages lifelong ethical monitoring as part of responsible innovation.
