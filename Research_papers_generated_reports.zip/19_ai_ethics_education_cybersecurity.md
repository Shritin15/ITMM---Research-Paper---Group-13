# 19_ai_ethics_education_cybersecurity
Title: Artificial Intelligence Ethics Education in Cybersecurity: Challenges and Opportunities
Link:  https://nsf.gov/awardsearch/showAward?AWD_ID=2114680

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Systems are black boxes, it’s really hard to understand how we can have access to these systems.
- Notes: Transparency is critical in developing trust and learning interpretability.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI ethics would be explainability. What the AI thinks should be somehow explained in some way other than what the black box shows.
- Notes: Explainability positioned as a key competency for AI ethics literacy.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Developers and managers must take responsibility for ensuring AI acts according to established ethical principles.
- Notes: Promotes accountability-driven pedagogy for ethical decision-making.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - AI should not completely replace human supervision; instead, it should enhance human decision-making.
- Notes: Encourages human-in-the-loop principles in AI systems and training.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Data has to be taken with permission.
- Notes: Privacy education viewed as the ethical foundation of AI cybersecurity.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Participants emphasised confidentiality and responsible data handling.
- Notes: Reinforces data security as an ethical and educational imperative.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI behavior must be monitored and audited in real time to ensure compliance with ethical principles.
- Notes: Continuous monitoring integrated as a recurring educational goal.
