# 01_unified_framework_ai_society
Title: A Unified Framework of Five Principles for AI in Society
Link:  https://doi.org/10.1162/99608f92.8cd550d1

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - All of them refer to the need to understand and hold to account the decision-making processes of AI… expressed as ‘transparency’ in Asilomar and EGE.
- Notes: Transparency explicitly identified as necessary for ethical AI decision-making.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Explicability, understood as intelligibility (‘how does it work?’) and accountability (‘who is responsible for the way it works?’).
- Notes: Introduces explicability as a synthesis of explainability and accountability.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Accountability… as an answer to the question ‘who is responsible for the way it works?’
- Notes: Responsibility for AI outcomes emphasized as a core element.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Humans should choose how and whether to delegate decisions to AI systems… any delegation should remain overridable.
- Notes: Highlights human decision control and meta-autonomy.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Prevention of infringements on personal privacy… included as a principle in five of the six sets.
- Notes: Privacy positioned within non-maleficence — essential to ethical design.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Avoid misuse… working against the risks arising from technological innovations.
- Notes: Responsible handling of data emphasized as part of harm prevention.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Framework adopted by AI4People and OECD AI Principles across 42 countries.
- Notes: Demonstrates institutionalization and long-term ethical governance.
