# 23_ai_hype_cybersecurity_ethics
Title: AI Hype as a Cyber Security Risk: The Moral Responsibility of Implementing Generative AI in Business
Link:  

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Implementing an AI solution into business should also come with relevant training as it should be clear who is accountable and responsible for its use.
- Notes: Transparency in processes and accountability structures enhances ethical deployment.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Companies should ensure their AI training is easily explainable and transparent in its design.
- Notes: Promotes explicability to ensure fair and understandable AI operation.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Explicability entails who is made accountable for failures in cyber security.
- Notes: Accountability emphasized as essential to assign responsibility in AI ethics.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Guardrails should be in place to ensure that AI implementation is not providing more avenues for employees to make mistakes.
- Notes: Human oversight required to prevent overreliance and ensure safety.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - By trusting generative AI systems to store and process data, organisations could also be exposing themselves to added security threats.
- Notes: Privacy framed as a moral and cybersecurity duty.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Companies need to ensure data collected is accurate, fair, representative, and legally sourced.
- Notes: Stresses fair, lawful, and transparent data use.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI model retraining and maintenance must be done to ensure it maintains its ethical standards and accuracy.
- Notes: Supports periodic evaluation and updating to sustain ethical performance.
