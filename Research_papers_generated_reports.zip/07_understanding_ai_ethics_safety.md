# 07_understanding_ai_ethics_safety
Title: Understanding Artificial Intelligence Ethics and Safety
Link:  https://arxiv.org/abs/1906.05684

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Transparency is necessary for establishing accountability and enabling effective regulation of AI systems.
- Notes: Transparency is defined as a prerequisite for regulation and trust.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI systems should be interpretable to ensure users can understand their decisions and identify sources of error.
- Notes: Explainability enhances reliability and user comprehension.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Responsibility for AI actions must remain with human designers and operators, not the systems themselves.
- Notes: Assigns moral and legal accountability explicitly to humans.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Humans must retain meaningful control and the capacity to override AI decisions.
- Notes: Supports oversight to prevent autonomous malfunction or abuse.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI development must respect individual autonomy and data privacy rights.
- Notes: Promotes respect for privacy and autonomy as core ethical obligations.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Data minimization and security must be integral to AI system design to avoid harm and misuse.
- Notes: Encourages privacy-by-design to safeguard data and prevent abuse.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ethics cannot be treated as a one-off compliance task; systems must be evaluated continuously to adapt to evolving risks.
- Notes: Reinforces the need for dynamic and ongoing ethical assessment.
