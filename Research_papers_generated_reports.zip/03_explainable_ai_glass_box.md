# 03_explainable_ai_glass_box
Title: Explainable AI: From Black Box to Glass Box
Link:  https://doi.org/10.1007/s11747-019-00710-5

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Explainable AI (XAI) is the class of systems that provide visibility into how an AI system makes decisions and predictions.
- Notes: XAI directly promotes transparency by exposing the reasoning process of AI systems.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - XAI explains the rationale for the decision-making process, surfaces the strengths and weaknesses of the process, and provides a sense of how the system will behave in the future.
- Notes: Central focus of the paper; distinguishes XAI as both a research goal and a design principle.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Providing users with an effective explanation for the AI system’s behavior can enhance their trust in the system.
- Notes: Positions explainability as a foundation for accountability and user trust.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Users and developers can inspect explanations to understand why specific actions or recommendations are made, allowing confidence in deploying models.
- Notes: Human involvement emphasized through interpretability review and inspection.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - XAI can redefine the privacy calculus of consumers, changing willingness to share personal information when explanations are provided.
- Notes: Direct link between explainability and informed consent in data privacy.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - XAI techniques can reveal whether attributes such as race or gender, or socio-economic variables are directly or indirectly used in black-box models.
- Notes: XAI promotes fairness and safeguards data integrity through model transparency.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ongoing explanation mechanisms can enhance fairness and trust, redefining the prediction-accuracy and explainability tradeoff.
- Notes: Encourages continuous oversight and adaptation of ethical AI systems.
