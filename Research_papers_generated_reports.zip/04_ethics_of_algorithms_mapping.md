# 04_ethics_of_algorithms_mapping
Title: The Ethics of Algorithms: Mapping the Debate
Link:  https://doi.org/10.1177/2053951716679679

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Algorithms have an epistemic opacity… this opacity creates barriers to accountability and governance.
- Notes: Transparency is treated as a prerequisite for moral and regulatory governance of AI systems.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Explainability is central to moral accountability and the ability to challenge algorithmic outcomes.
- Notes: Explainability is directly tied to fairness and justification of automated decisions.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - The allocation of responsibility in complex algorithmic systems requires clarity on who is morally and legally accountable.
- Notes: Highlights distributed responsibility as a key ethical challenge.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Human decision-makers must remain involved to ensure that algorithmic outputs are contextualized and ethically defensible.
- Notes: Emphasizes human-in-the-loop systems for ethical governance.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Algorithms may process data in ways that are opaque to individuals, raising privacy and autonomy concerns.
- Notes: Discusses data misuse, profiling, and surveillance risks.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Algorithmic design must integrate data protection principles, particularly proportionality and minimization.
- Notes: Advocates privacy-by-design and responsible data architecture.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Algorithmic ethics cannot be static… continuous evaluation and governance are necessary as systems evolve.
- Notes: Calls for adaptive ethics and long-term monitoring mechanisms.
