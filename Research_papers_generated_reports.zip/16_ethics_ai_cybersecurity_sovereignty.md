# 16_ethics_ai_cybersecurity_sovereignty
Title: Ethics of AI and Cybersecurity When Sovereignty is at Stake
Link:  https://doi.org/10.1007/s11023-019-09508-4

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Transparency confidence-building measures include information exchange on cyber threats and joint cyber exercises.
- Notes: Transparency seen as a key ethical principle for cooperation in AI-enabled cybersecurity.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI is not transparent in how it reaches decisions from data points, yet operators may blindly trust that decision.
- Notes: Emphasizes need for explainable AI to reduce overreliance and improve trust.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Unfair allocation of liability, the fallacy of human-in-the-loop, and residual risk management raise accountability dilemmas.
- Notes: Defines accountability across human, institutional, and state levels.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - We need to rethink risk management rules when de facto we have the human out of the loop for AI-enabled critical infrastructure resilience.
- Notes: Warns against losing human oversight in automated cyber defense.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI-based monitoring and risk prevention can be highly intrusive and coercive for people.
- Notes: Identifies privacy risks in AI-driven surveillance systems.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Transparency CBMs include mutual software code inspection and open information exchange on cyber threats.
- Notes: Promotes collaborative, secure data sharing as part of ethical resilience.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI behavior must be monitored and audited in real time to ensure compliance with ethical principles.
- Notes: Encourages continuous ethical auditing aligned with AI evolution.
