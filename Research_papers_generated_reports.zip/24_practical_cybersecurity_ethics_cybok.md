# 24_practical_cybersecurity_ethics_cybok
Title: Practical Cybersecurity Ethics: Mapping CyBOK to Ethical Concerns
Link:  

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Disclosing security risks without making users feel insecure… a transparent business practice that improves transparency and ensures users take informed decisions.
- Notes: Transparency must balance public reassurance and openness.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Cybersecurity technologies should be used in ways that are intelligible, transparent, and comprehensible, and it should also be clear who is accountable and responsible.
- Notes: Explicability central to principlist framework and AI security ethics.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ensuring accountability and responsibility in AI… lack of transparency in how AI systems make decisions.
- Notes: AI introduces risks of accountability diffusion in cybersecurity practice.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - We avoid retaliating in DDoS defense… we go through legal means.
- Notes: Ethical restraint through human oversight prevents escalation.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - We drop malicious packets without inspecting user data to protect privacy.
- Notes: Balances network defense with user privacy rights.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Maintaining confidentiality is highly critical… deciding between maintaining or breaking it in case of harm or crime.
- Notes: Highlights confidentiality as a foundational cybersecurity ethic.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - We urge the research community to continue exploring the ethics of cybersecurity AI… and integrate ethics into the cybersecurity curriculum.
- Notes: Emphasizes the need for education and iterative ethical reflection.
