# 00_baseline_securing_trust_ai_cybersecurity
Title: Securing Trust: Ethical Considerations in AI for Cybersecurity
Link:  https://doi.org/10.60087/jklst.vol2.n2.P175

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Decisions made using AI are not only transparent but also simple to comprehend in vigorous cybersecurity contexts.
- Notes: Transparency emphasized as essential for trustworthy AI cybersecurity.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Understanding how AI systems make decisions is essential to building trust among stakeholders.
- Notes: Recognizes algorithmic opacity as a challenge in cybersecurity.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Establishing strong accountability requires collaboration between policymakers, cybersecurity experts, and AI developers.
- Notes: Highlights shared responsibility between human and institutional actors.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - Humans must validate and supervise AI-based responses to ensure ethical compliance.
- Notes: Maintains human-in-the-loop oversight principle.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Data should be protected at all costs which is the ultimate aim of cybersecurity systems.
- Notes: Positions privacy as fundamental to ethical governance.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Policies for data protection should be in place and threats should be detected using AI tools to protect sensitive data.
- Notes: Data protection treated as both ethical and operational safeguard.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Ethical systems should be continuously monitored and updated for prompt resolution of emerging issues.
- Notes: Proposes lifecycle ethical monitoring as a structural requirement.
