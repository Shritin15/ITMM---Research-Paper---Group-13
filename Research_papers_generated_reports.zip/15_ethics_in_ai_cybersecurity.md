# 15_ethics_in_ai_cybersecurity
Title: Ethics in Artificial Intelligence: An Approach to Cybersecurity
Link:  https://doi.org/10.4114/intartif.vol27iss73pp38-54

## Real-Time Transparency
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI systems should be designed so that their decisions and actions are understandable to humans. Transparency allows greater accountability.
- Notes: Transparency integrated to support interpretability and oversight in cyber defense.

## Explainability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Interpretability and transparency of AI algorithms are crucial for trust and safety in cybersecurity.
- Notes: Advocates for explainable AI to reduce algorithmic opacity.

## Accountability
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Developers and managers must take responsibility for ensuring AI acts according to established ethical principles.
- Notes: Highlights shared accountability between human and institutional actors.

## Human Oversight
- Score: 10 / 10  (Explicit evidence → full weight)
- Evidence pointers:
  - AI should not completely replace human supervision; instead, it should enhance human decision-making.
- Notes: Encourages a hybrid human–machine ethical decision model.

## Privacy
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - It is essential to ensure robust data protection mechanisms and respect the ethical principles of privacy and confidentiality.
- Notes: Privacy positioned as a foundational ethical obligation.

## Data Protection
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - Cybersecurity is essential in AI system development. Systems must be protected against attacks and vulnerabilities.
- Notes: Aligns cybersecurity protection with ethical compliance.

## Continuous Ethical Monitoring (Lifecycle Governance)
- Score: 15 / 15  (Explicit evidence → full weight)
- Evidence pointers:
  - AI behavior must be monitored and audited in real time to ensure compliance with ethical principles.
- Notes: Continuous monitoring ensures evolving ethical governance.
